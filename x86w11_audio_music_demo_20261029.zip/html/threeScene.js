/**
 * threeScene.js
 * 3D场景、传感器、光束、角度计算、UI差值更新
 * 传统脚本：依赖全局 THREE（three.min.js）与 THREE.OrbitControls（examples/js/controls/OrbitControls.js）
 * MAX_DIFF_DEG 由 sensorStruct.js 以全局常量提供（需在其之后加载）
 */

let scene, camera, renderer, controls;
let sensorPivot, beamSet, beamCalc;

let currentSetData = { az: 0, el: -45 };
let currentCalcData = { az: 0, el: -45 };

function setSetData(d) { currentSetData = {...d}; }
function setCalcData(d) { currentCalcData = {...d}; }

function createGradientWallMaterial({ height = 10, color = "#00ffff", opacity = 0.5 } = {}) {
    const vertexShader = `
        varying float vHeightRatio;
        uniform float u_height;
        void main() {
            vHeightRatio = position.y / u_height;
            gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
        }
    `;
    const fragmentShader = `
        uniform vec3 u_color;
        uniform float u_opacity;
        varying float vHeightRatio;
        void main() {
            float alpha = (1.0 - vHeightRatio) * u_opacity;
            gl_FragColor = vec4(u_color, alpha);
        }
    `;
    return new THREE.ShaderMaterial({
        uniforms: {
            u_height: { value: height },
            u_opacity: { value: opacity },
            u_color: { value: new THREE.Color(color) }
        },
        vertexShader, fragmentShader,
        transparent: true,
        side: THREE.DoubleSide,
        depthWrite: false,
        blending: THREE.AdditiveBlending
    });
}

function setupLights() {
    const ambient = new THREE.AmbientLight(0xffffff, 0.4);
    scene.add(ambient);
    const dir = new THREE.DirectionalLight(0xffffff, 1);
    dir.position.set(20, 50, 20);
    dir.castShadow = true;
    scene.add(dir);
}

function createEnvironment() {
    const grid = new THREE.GridHelper(100, 50, 0x00ffff, 0x0088ff);
    scene.add(grid);
    const plane = new THREE.Mesh(
        new THREE.PlaneGeometry(100, 100),
        new THREE.MeshStandardMaterial({ color: 0x020617, roughness: 0.8 })
    );
    plane.rotation.x = -Math.PI / 2;
    plane.position.y = -0.01;
    plane.receiveShadow = true;
    scene.add(plane);

    const wallMat = createGradientWallMaterial({ height: 10, color: "#0088ff", opacity: 0.4 });
    const geoX = new THREE.PlaneGeometry(20, 20);
    const wallX = new THREE.Mesh(geoX, wallMat);
    wallX.rotation.y = Math.PI / 2;
    wallX.position.set(0, 5, 0);
    scene.add(wallX);

    const wallMat2 = createGradientWallMaterial({ height: 10, color: "#00ff88", opacity: 0.2 });
    const geoZ = new THREE.PlaneGeometry(20, 20);
    const wallZ = new THREE.Mesh(geoZ, wallMat2);
    wallZ.position.set(0, 5, 0);
    scene.add(wallZ);
}

function createSensor() {
    const mainGroup = new THREE.Group();
    mainGroup.position.set(0, 20, 0);
    scene.add(mainGroup);
    sensorPivot = new THREE.Group();
    mainGroup.add(sensorPivot);

    const pcbRadius = 4.2;
    const pcbGeo = new THREE.CircleGeometry(pcbRadius, 64);
    const pcbMat = new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.7, metalness: 0.05 });
    const pcbBoard = new THREE.Mesh(pcbGeo, pcbMat);
    pcbBoard.rotation.x = -Math.PI / 2;
    sensorPivot.add(pcbBoard);

    const pcbBorderGeo = new THREE.RingGeometry(pcbRadius - 0.08, pcbRadius, 64);
    const pcbBorderMat = new THREE.MeshBasicMaterial({ color: 0xcccccc, side: THREE.DoubleSide });
    const pcbBorder = new THREE.Mesh(pcbBorderGeo, pcbBorderMat);
    pcbBorder.rotation.x = -Math.PI / 2;
    pcbBorder.position.y = 0.02;
    sensorPivot.add(pcbBorder);

    const micGroup = new THREE.Group();
    sensorPivot.add(micGroup);
    const baseRadius = 0.8;
    const baseHeight = 2.2;
    const baseGeo = new THREE.CylinderGeometry(baseRadius, baseRadius * 1.05, baseHeight, 32);
    const baseMat = new THREE.MeshStandardMaterial({ color: 0x22aa44, roughness: 0.5, metalness: 0.1 });
    const micBase = new THREE.Mesh(baseGeo, baseMat);
    micBase.position.y = baseHeight / 2;
    micGroup.add(micBase);

    const ringRadius = 0.65;
    const ringHeight = 0.18;
    const connectRingGeo = new THREE.CylinderGeometry(ringRadius, ringRadius, ringHeight, 32);
    const connectRingMat = new THREE.MeshStandardMaterial({ color: 0xaaaaaa, roughness: 0.3, metalness: 0.6 });
    const connectRing = new THREE.Mesh(connectRingGeo, connectRingMat);
    connectRing.position.y = baseHeight + ringHeight / 2;
    micGroup.add(connectRing);

    const blackRingGeo = new THREE.CylinderGeometry(0.58, 0.58, 0.12, 32);
    const blackRingMat = new THREE.MeshStandardMaterial({ color: 0x222222, roughness: 0.4, metalness: 0.2 });
    const blackRing = new THREE.Mesh(blackRingGeo, blackRingMat);
    blackRing.position.y = baseHeight + ringHeight + 0.06;
    micGroup.add(blackRing);

    const ballRadius = 0.55;
    const ballGeo = new THREE.SphereGeometry(ballRadius, 32, 32);
    const ballMat = new THREE.MeshStandardMaterial({ color: 0xff2222, roughness: 0.3, metalness: 0.2 });
    const micBall = new THREE.Mesh(ballGeo, ballMat);
    micBall.position.y = baseHeight + ringHeight + 0.12 + ballRadius;
    micGroup.add(micBall);

    const grillGeo = new THREE.SphereGeometry(ballRadius + 0.05, 32, 16, 0, Math.PI * 2, 0, Math.PI / 2);
    const grillMat = new THREE.MeshStandardMaterial({ color: 0xdddddd, roughness: 0.25, metalness: 0.7 });
    const grill = new THREE.Mesh(grillGeo, grillMat);
    grill.position.y = micBall.position.y;
    micGroup.add(grill);
    micGroup.position.y = -0.6;

    beamSet = createBeam(0xff0000);
    sensorPivot.add(beamSet);
    beamCalc = createBeam(0x00ff00);
    sensorPivot.add(beamCalc);

    const verticalLinePoints = [new THREE.Vector3(0,0,0), new THREE.Vector3(0,-20,0)];
    const verticalLineGeo = new THREE.BufferGeometry().setFromPoints(verticalLinePoints);
    const verticalLineMat = new THREE.LineBasicMaterial({ color:0xffffff, opacity:0.5, transparent:true });
    const verticalLine = new THREE.Line(verticalLineGeo, verticalLineMat);
    mainGroup.add(verticalLine);
}

function createBeam(color) {
    const group = new THREE.Group();
    const lineGeo = new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(0,0,0), new THREE.Vector3(0,-15,0)]);
    const line = new THREE.Line(lineGeo, new THREE.LineBasicMaterial({ color, transparent:true, opacity:0.8 }));
    group.add(line);
    const coneHeight = 15;
    const coneGeo = new THREE.ConeGeometry(0.5, coneHeight, 32, 1, false);
    coneGeo.translate(0, -coneHeight / 2, 0);
    const coneMat = new THREE.MeshBasicMaterial({ color, transparent:true, opacity:0.1, side:THREE.DoubleSide, depthWrite:false, blending:THREE.AdditiveBlending });
    const cone = new THREE.Mesh(coneGeo, coneMat);
    group.add(cone);
    return group;
}

function getQuaternionFromAngles(azDeg, elDeg) {
    const azRad = THREE.MathUtils.degToRad(azDeg);
    const elRad = THREE.MathUtils.degToRad(elDeg);
    const targetDir = new THREE.Vector3(
        Math.cos(elRad) * Math.sin(azRad),
        Math.sin(elRad),
        Math.cos(elRad) * Math.cos(azRad)
    ).normalize();
    const defaultDir = new THREE.Vector3(0, -1, 0);
    const q = new THREE.Quaternion();
    q.setFromUnitVectors(defaultDir, targetDir);
    return q;
}

function updateBeamsVisuals() {
    if(!beamSet || !beamCalc) return;
    beamSet.quaternion.copy(getQuaternionFromAngles(currentSetData.az, currentSetData.el));
    beamCalc.quaternion.copy(getQuaternionFromAngles(currentCalcData.az, currentCalcData.el));
    
    const diffAz = currentCalcData.az - (currentSetData.set_az ?? currentSetData.az);
    const diffEl = currentCalcData.el - (currentSetData.set_el ?? currentSetData.el);
	
    document.getElementById('disp-diff-az').textContent = diffAz.toFixed(2)+"°";
    document.getElementById('disp-diff-el').textContent = diffEl.toFixed(2)+"°";

    const posAz = Math.max(0, Math.min(100, ((diffAz + MAX_DIFF_DEG) / (MAX_DIFF_DEG * 2)) * 100));
    const posEl = Math.max(0, Math.min(100, ((diffEl + MAX_DIFF_DEG) / (MAX_DIFF_DEG * 2)) * 100));
    document.getElementById('marker-diff-az').style.left = posAz + "%";
    document.getElementById('marker-diff-el').style.left = posEl + "%";
}

function onWindowResize() {
    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(window.innerWidth, window.innerHeight);
}

function animate() {
    requestAnimationFrame(animate);
    controls.update();
    renderer.render(scene, camera);
}

function initScene(containerDom) {
    scene = new THREE.Scene();
    scene.background = new THREE.Color(0x020617);
    scene.fog = new THREE.FogExp2(0x020617, 0.015);
    camera = new THREE.PerspectiveCamera(50, window.innerWidth / window.innerHeight, 0.1, 200);
    camera.position.set(30, 25, 30);
    renderer = new THREE.WebGLRenderer({ antialias: true });
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.setPixelRatio(window.devicePixelRatio);
    containerDom.appendChild(renderer.domElement);
    controls = new THREE.OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.maxPolarAngle = Math.PI / 2 - 0.05;
    controls.enabled = false;

    setupLights();
    createEnvironment();
    createSensor();
    updateBeamsVisuals();
	
    window.addEventListener('resize', onWindowResize);
    animate();
}
function initScene_mesh(container) {
    // --- Initialization ---
	scene = new THREE.Scene();
	scene.background = new THREE.Color(0x0f172a);
	//scene.fog = new THREE.Fog(0x0f172a, 20, 100);

	camera = new THREE.PerspectiveCamera(45, window.innerWidth / window.innerHeight, 0.1, 1000);
	//camera.position.set(20, 20, 20);
	//camera.position.set(0, 0, 50);
	camera.position.set(300, 300, 300);			

	renderer = new THREE.WebGLRenderer({ antialias: true });
	renderer.setSize(window.innerWidth, window.innerHeight);
	renderer.setPixelRatio(window.devicePixelRatio);
	renderer.shadowMap.enabled = true;
	container.appendChild(renderer.domElement);

	controls = new THREE.OrbitControls(camera, renderer.domElement);
	controls.enableDamping = true;
	controls.maxPolarAngle = Math.PI / 2 - 0.05;

	// Lighting
	const ambientLight = new THREE.AmbientLight(0xffffff, 0.4);
	scene.add(ambientLight);
	const dirLight = new THREE.DirectionalLight(0xffffff, 0.8);
	dirLight.position.set(10, 20, 10);
	dirLight.castShadow = true;
	scene.add(dirLight);

	loadExample();
	window.addEventListener('resize', onWindowResize);
	animate();
        
}
