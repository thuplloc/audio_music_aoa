/**
 * sensorStruct.js
 * 结构体打包解包 + base64 转换
 * 传统脚本：无 import/export，函数与常量直接挂在全局
 */
const MAX_DIFF_DEG = 10;
// 23  lines
// 128 float
// 604 bytes
function packSensorStruct(obj) {
    const HEAD_BYTES = 84 + 4;
    const rxMatrixLen = obj.rx_matrixlen ?? 0;
    const totalBytes = HEAD_BYTES + rxMatrixLen +4;
    const buf = new ArrayBuffer(totalBytes);
    const dv = new DataView(buf);
    let offset = 0;

    dv.setInt32(offset, HEAD_BYTES, true); offset +=4;
    dv.setInt32(offset, obj.id, true); offset +=4;
    dv.setInt32(offset, obj.timesrc, true); offset +=4;
    dv.setInt32(offset, obj.timeapp, true); offset +=4;
    dv.setInt32(offset, obj.timeappe, true); offset +=4;
    dv.setInt32(offset, obj.timeback, true); offset +=4;
    dv.setInt32(offset, obj.time1, true); offset +=4;
    dv.setInt32(offset, obj.time2, true); offset +=4;
    dv.setInt32(offset, obj.setlen, true); offset +=4;
    dv.setInt32(offset, obj.azlen, true); offset +=4;

    dv.setFloat32(offset, obj.set_az[0], true); offset +=4;
    dv.setFloat32(offset, obj.set_az[1], true); offset +=4;
    dv.setFloat32(offset, obj.set_el[0], true); offset +=4;
    dv.setFloat32(offset, obj.set_el[1], true); offset +=4;

    dv.setFloat32(offset, obj.az[0], true); offset +=4;
    dv.setFloat32(offset, obj.az[1], true); offset +=4;
    dv.setFloat32(offset, obj.az[2], true); offset +=4;
    dv.setFloat32(offset, obj.az[3], true); offset +=4;

    dv.setFloat32(offset, obj.el[0], true); offset +=4;
    dv.setFloat32(offset, obj.el[1], true); offset +=4;
    dv.setFloat32(offset, obj.el[2], true); offset +=4;
    dv.setFloat32(offset, obj.el[3], true); offset +=4;

    dv.setInt32(offset, rxMatrixLen, true); offset +=4;

    //const last16 = obj.rx_matrix.slice(-16);
    //console.log("float data:",obj.rx_matrix.length,last16);
    
	if(rxMatrixLen > 0 && obj.rx_matrix) {
        const ELEM_BYTE = 4;
        if(rxMatrixLen % ELEM_BYTE !== 0){
            console.error(`pack: rx_matrixlen(${rxMatrixLen})不能被${ELEM_BYTE}整除`);
        }else{
            const elemCount = rxMatrixLen / ELEM_BYTE;
			//console.log("elemCount",elemCount);
            for(let i=0; i<elemCount; i++){
                if(offset + ELEM_BYTE > dv.buffer.byteLength){
					console.log("why beyond this.",offset + ELEM_BYTE,dv.buffer.byteLength,totalBytes);
					break;
				}
                
				dv.setFloat32(offset, obj.rx_matrix[i], true);
                offset += ELEM_BYTE;
            }
        }
    }
	// 23 times write, 2*8*8 = 604
	let outarray = new Uint8Array(buf);
	//console.log("outarray",outarray.length);
    return outarray;
}

function unpackSensorStruct(uint8Arr) {
    const buf = uint8Arr.buffer;
    const dv = new DataView(buf, uint8Arr.byteOffset, uint8Arr.byteLength);
    let offset =0;
    const ret = {};
    ret.head_len = dv.getInt32(offset,true); offset +=4;
    ret.id = dv.getInt32(offset,true); offset +=4;
    ret.timesrc = dv.getInt32(offset,true); offset +=4;
    ret.timeapp = dv.getInt32(offset,true); offset +=4;
    ret.timeappe = dv.getInt32(offset,true); offset +=4;
    //ret.timeback = dv.getInt32(offset,true); offset +=4;
	ret.timeback = Date.now() & 0x7FFFFFFF ; offset +=4;
    ret.time1 = dv.getInt32(offset,true); offset +=4;
    ret.time2 = dv.getInt32(offset,true); offset +=4;
    ret.setlen = dv.getInt32(offset,true); offset +=4;
    ret.azlen = dv.getInt32(offset,true); offset +=4;

    ret.set_az = [dv.getFloat32(offset,true), dv.getFloat32(offset+4,true)]; offset +=8;
    ret.set_el = [dv.getFloat32(offset,true), dv.getFloat32(offset+4,true)]; offset +=8;
    ret.az = [
        dv.getFloat32(offset,true),
        dv.getFloat32(offset+4,true),
        dv.getFloat32(offset+8,true),
        dv.getFloat32(offset+12,true)
    ]; offset +=16;
    ret.el = [
        dv.getFloat32(offset,true),
        dv.getFloat32(offset+4,true),
        dv.getFloat32(offset+8,true),
        dv.getFloat32(offset+12,true)
    ]; offset +=16;
    ret.rx_matrixlen = dv.getInt32(offset,true); offset +=4;
    ret.rx_matrix = [];
    if(ret.rx_matrixlen > 0){
        const ELEM_BYTE = 4;
        if(ret.rx_matrixlen % ELEM_BYTE ===0){
            const elemCount = ret.rx_matrixlen / ELEM_BYTE;
            for(let i=0; i<elemCount; i++){
                if(offset + ELEM_BYTE > dv.buffer.byteLength) break;
                ret.rx_matrix.push(dv.getFloat32(offset,true));
                offset += ELEM_BYTE;
            }
        }
    }
    return ret;
}
function unpackSensorStruct2(uint8Arr) {
    const buf = uint8Arr.buffer;
    const dv = new DataView(buf, uint8Arr.byteOffset, uint8Arr.byteLength);
    let offset =0;
    const ret = {};
    ret.head_len = dv.getInt32(offset,true); offset +=4;
    ret.id = dv.getInt32(offset,true); offset +=4;
	
	ret.pmusic = [];
	for(let i=0;i<23;i++){
		for(let j=0;j<46;j++){
		    ret.pmusic.push ( dv.getFloat32(offset,true) ); offset +=4;
	    }
	}
	
    return ret;
}
function uint8ToBase64(bytes) {
    let binary = "";
    for(let i=0;i<bytes.length;i++){
        binary += String.fromCharCode(bytes[i]);
    }
    return btoa(binary);
}

function base64ToUint8(b64) {
    const bin = atob(b64);
    const arr = new Uint8Array(bin.length);
    for(let i=0;i<bin.length;i++) arr[i] = bin.charCodeAt(i);
    return arr;
}
