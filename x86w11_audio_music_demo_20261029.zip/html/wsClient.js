/**
 * wsClient.js
 * ws://localhost:8001 客户端，订阅 zystock/plaoa
 * 传统脚本：无 import/export，回调通过全局函数注册
 */
let ws = null;
const WS_URL = "ws://localhost:8001/ws";
const SUB_TOPIC = "zystock/plaoa";
let reconnectTimer = null;
let onMessageCallback = null;
let onStatusChange = null;

function setMsgCallback(cb) {
    onMessageCallback = cb;
}
function setStatusCallback(cb) {
    onStatusChange = cb;
}

function updateStatus(text, cls) {
    if (onStatusChange) onStatusChange(text, cls);
}

function connect() {
    if (ws && (ws.readyState === WebSocket.OPEN || ws.readyState === WebSocket.CONNECTING)) {
        return;
    }
    ws = new WebSocket(WS_URL);
    updateStatus("连接中", "conn-yellow");

    ws.onopen = () => {
        console.log("ws open, subscribe:", SUB_TOPIC);
        // 发送订阅指令，根据你的服务端协议：这里直接发主题字符串


		const payload = {
                action: "subscribe",
                needtopic: `${SUB_TOPIC}`
            };
            const msgStr = JSON.stringify(payload);
		 ws.send(msgStr);
        updateStatus("已连接", "conn-green");
        clearTimeout(reconnectTimer);
    };

    ws.onmessage = (evt) => {
        if (onMessageCallback) {
			if( evt.data.indexOf("app,musicdata") == 0 ){
				
			}else{
                onMessageCallback(evt.data);
			}
        }
    };

    ws.onclose = () => {
        console.warn("ws closed, try reconnect");
        updateStatus("已断开", "conn-red");
        scheduleReconnect();
    };

    ws.onerror = (err) => {
        console.error("ws error", err);
        updateStatus("错误", "conn-red");
    };
}

function scheduleReconnect() {
    clearTimeout(reconnectTimer);
    reconnectTimer = setTimeout(() => {
        connect();
    }, 2000);
}

function publish(msg) {
    if (!ws || ws.readyState !== WebSocket.OPEN) {
        console.warn("ws未就绪，无法发送", msg);
        return false;
    }
	let tmp={topic:SUB_TOPIC,cont:msg};
	//console.log( JSON.stringify(tmp)   );
    ws.send(JSON.stringify(tmp) );
    return true;
}

function destroy() {
    clearTimeout(reconnectTimer);
    if (ws) {
        ws.close();
        ws = null;
    }
}

// 自动连接
connect();
