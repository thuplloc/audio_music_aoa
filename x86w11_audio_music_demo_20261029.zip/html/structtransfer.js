/**
 * 解析结构体文本，提取字段的类型、名称和字节宽度
 */
function parseStructText(structText) {
    const fields = [];
    // 匹配类型和变量名，忽略行首尾空格和分号
    const lineReg = /^\s*(int32_t|uint32_t|int16_t|uint16_t|int8_t|uint8_t)\s+([a-zA-Z0-9_]+)\s*;?\s*$/gm;
    let match;
    while ((match = lineReg.exec(structText)) !== null) {
        const typeStr = match[1];
        const nameStr = match[2];
        let width;
        switch (typeStr) {
            case 'int32_t':
            case 'uint32_t': width = 4; break;
            case 'int16_t':
            case 'uint16_t': width = 2; break;
            case 'int8_t':
            case 'uint8_t': width = 1; break;
            default: throw new Error(`不支持的字段类型: ${typeStr}`);
        }
        fields.push({ type: typeStr, name: nameStr, width: width });
    }
    return fields;
}

/**
 * 初始化字段值：
 * 1. 以 structText 定义的字段为准，默认值全部设为 0
 * 2. 从 jsonStr 中读取值，如果存在则覆盖默认值
 * 3. 如果 JSON 中的值是数组，识别为多值字段用于生成组合
 */
function initFieldMultiValues(fields, jsonStr) {
    let jsonObj = {};
    try {
        jsonObj = JSON.parse(jsonStr);
    } catch (e) {
        console.warn("JSON 解析失败，将使用全 0 默认值", e);
    }

    const baseObj = {};      // 存储单值字段的最终值（默认0，或被JSON单值覆盖）
    const multiFields = [];  // 存储多值字段信息

    fields.forEach(field => {
        const fieldName = field.name;
        const jsonVal = jsonObj[fieldName];

        if (Array.isArray(jsonVal)) {
            // 如果 JSON 中是数组，加入多值列表
            // 注意：这里不从 baseObj 中取默认值，因为多值会在 cartesianProduct 中处理
            multiFields.push({
                name: fieldName,
                values: jsonVal
            });
            // 多值字段在 baseObj 中可以先设一个占位符，或者留空，
            // 但在后续 map 中我们会用 combo 覆盖它，所以这里设 0 也可以
            baseObj[fieldName] = 0; 
        } else {
            // 如果 JSON 中有单值，使用该值；如果没有，保持默认 0
            // 确保值是数字类型，防止字符串导致后续位运算错误
            baseObj[fieldName] = (jsonVal !== undefined && jsonVal !== null) ? Number(jsonVal) : 0;
        }
    });

    return { baseObj, multiFields };
}

/**
 * 笛卡尔积生成所有组合
 */
function cartesianProduct(multiFields) {
    if (multiFields.length === 0) return [{}];
    
    return multiFields.reduce((prev, curr) => {
        const res = [];
        prev.forEach(p => {
            curr.values.forEach(v => {
                res.push({ ...p, [curr.name]: v });
            });
        });
        return res;
    }, [{}]);
}

/**
 * 16位整数转小端字节数组
 */
function uint16ToLittleEndian(val) {
    val = val & 0xFFFF;
    return [val & 0xFF, (val >> 8) & 0xFF];
}

/**
 * 32位整数转小端字节数组
 */
function uint32ToLittleEndian(val) {
    val = val >>> 0; // 转为无符号32位整数处理负数补码
    return [
        val & 0xFF,
        (val >> 8) & 0xFF,
        (val >> 16) & 0xFF,
        (val >> 24) & 0xFF
    ];
}

/**
 * 构建原始结构体字节数组
 */
function buildByteArray(fields, vals, bitMode = 32) {
    const rawArr = [];
    fields.forEach(field => {
        // 获取值，如果不存在则默认为 0
        const val = vals[field.name] ?? 0;
        
        switch (field.type) {
            case 'int8_t':
            case 'uint8_t':
                rawArr.push(val & 0xFF);
                break;
            case 'int16_t':
            case 'uint16_t':
                rawArr.push(...uint16ToLittleEndian(val));
                break;
            case 'int32_t':
            case 'uint32_t':
                rawArr.push(...uint32ToLittleEndian(val));
                break;
        }
    });
    return rawArr;
}

/**
 * CRC16 计算 (CCITT-FALSE / MODBUS 等常见变体需确认多项式和初始值，此处沿用原代码参数)
 */
function crc16Bit(data, len, poly, init) {
    let crc = init;
    for (let i = 0; i < len; i++) {
        crc ^= (data[i] << 8);
        for (let j = 0; j < 8; j++) {
            crc = (crc & 0x8000) ? ((crc << 1) ^ poly) : (crc << 1);
            crc &= 0xFFFF;
        }
    }
    return crc;
}

/**
 * 字节数组转 Base64
 */
function bytesToBase64(bytes) {
    const uint8Arr = new Uint8Array(bytes);
    let binaryStr = '';
    for (let i = 0; i < uint8Arr.length; i++) {
        binaryStr += String.fromCharCode(uint8Arr[i]);
    }
    return btoa(binaryStr);
}
////////////
function parseStructFields(code) {
    // 1. 去除 // 开头的注释行
    let cleaned = code.replace(/\/\/.*$/gm, '');
    
    // 2. 去除 /* */ 中间的注释（包含注释符号本身）
    cleaned = cleaned.replace(/\/\*[\s\S]*?\*\//g, '');
    
    // 3. 按行分割，过滤空行和纯空白行
    const lines = cleaned.split('\n').filter(line => line.trim().length > 0);
    
    const result = {};
    
    // 定义类型映射规则，用于分类（虽然题目主要要求输出 {name: type}，但内部逻辑需识别类型）
    // 这里我们直接提取声明中的类型和变量名
    // 正则解释：
    // ^\s* : 开头空白
    // (\w+) : 捕获组1，类型 (如 uint32_t)
    // \s+ : 中间空白
    // (\w+) : 捕获组2，变量名 (如 INFO_0)
    // \s*; : 结尾分号前的可选空白和分号
    const regex = /^\s*(\w+)\s+(\w+)\s*;/;

    lines.forEach(line => {
        const match = line.match(regex);
        if (match) {
            const type = match[1];
            const variable = match[2];
            
            // 题目要求区分类型，但最终输出格式示例为 {"INFO_9": "uint32_t"}
            // 如果需要更详细的分类信息，可以在此处扩展，但根据最终输出要求，我们存储类型字符串
            result[variable] = type;
        }
    });

    return result;
}
//////////
function packStructToLittleEndian(allField, jsonStr) {
    // 1. 解析 JSON 字符串
    let dataSrc = {};
    try {
        dataSrc = JSON.parse(jsonStr);
    } catch (e) {
        console.error("JSON 解析失败:", e);
        return new Uint8Array(0);
    }

    // 2. 计算总字节大小并准备缓冲区
    // 我们需要先遍历一次以确定总大小，或者直接使用 DataView 动态写入
    // 为了简单且高效，我们先计算总字节数
    let totalBytes = 0;
    const fieldList = []; // 存储待处理的字段信息 { name, type, value }

    for (const [key, type] of Object.entries(allField)) {
        // 获取值：如果 jsonStr 中没有，默认为 0；如果是数组，取第一个
        let rawValue = dataSrc[key];
        let value = 0;

        if (rawValue !== undefined) {
            if (Array.isArray(rawValue)) {
                value = rawValue.length > 0 ? rawValue[0] : 0;
            } else {
                value = rawValue;
            }
        } else {
            value = 0; // 找不到定义，赋值为 0
        }

        // 确定该类型占用的字节数
        let byteSize = 0;
        switch (type) {
            case 'uint8_t':
            case 'int8_t':
                byteSize = 1;
                break;
            case 'uint16_t':
            case 'int16_t':
                byteSize = 2;
                break;
            case 'uint32_t':
            case 'int32_t':
            case 'float': // float 通常是 32 位
                byteSize = 4;
                break;
            case 'double':
                byteSize = 8;
                break;
            default:
                // 未知类型默认按 4 字节处理或跳过，这里假设默认 4 字节以防错位
                console.warn(`未知类型: ${type}，默认按 4 字节处理`);
                byteSize = 4;
        }

        totalBytes += byteSize;
        fieldList.push({ name: key, type: type, value: value, size: byteSize });
    }

    // 3. 创建 ArrayBuffer 和 DataView
    const buffer = new ArrayBuffer(totalBytes);
    const view = new DataView(buffer);
    
    let offset = 0; // 当前写入偏移量

    // 4. 按照小端模式写入数据
    fieldList.forEach(field => {
        const { type, value, size } = field;
        
        // 确保值是数字类型
        const numValue = Number(value);

        switch (type) {
            case 'uint8_t':
                view.setUint8(offset, numValue);
                break;
            case 'int8_t':
                view.setInt8(offset, numValue);
                break;
            case 'uint16_t':
                view.setUint16(offset, numValue, true); // true = Little Endian
                break;
            case 'int16_t':
                view.setInt16(offset, numValue, true);
                break;
            case 'uint32_t':
                view.setUint32(offset, numValue, true);
                break;
            case 'int32_t':
                view.setInt32(offset, numValue, true);
                break;
            case 'float':
                view.setFloat32(offset, numValue, true);
                break;
            case 'double':
                view.setFloat64(offset, numValue, true);
                break;
            default:
                //  fallback: 尝试按 32 位无符号整数写入
                view.setUint32(offset, numValue, true);
        }

        offset += size;
    });

    // 返回 Uint8Array 以便查看或传输字节流
    return new Uint8Array(buffer);
}

/**
 * 主函数：结构体转 Base64
 */
function structToBase64(structText, jsonStr, bitMode = 32) {
    if (![8, 32].includes(bitMode)) bitMode = 32;
    let allfileds = parseStructFields(structText);
    	
	let allbytes = packStructToLittleEndian(allfileds,jsonStr);
	
	let binary = '';
    const len = allbytes.byteLength;
    for (let i = 0; i < len; i++) {
        binary += String.fromCharCode(allbytes[i]);
    }
    let base64ed = window.btoa(binary);
	
	

    return base64ed;
}

