/**
 * app.js 入口主逻辑
 * 传统脚本：依赖 threeScene.js / sensorStruct.js / wsClient.js / musicdata.js 提供的全局函数
 * 加载顺序需为：three -> OrbitControls -> musicdata.js -> sensorStruct.js -> wsClient.js -> threeScene.js -> app.js
 */

let tcalcValue = 0;
let twebValue = 0;
let testInterval = null;
const MAX_MSG = 50;
let msgCache = [];

// WS状态UI更新
setStatusCallback((text, cls)=>{
    const wrap = document.getElementById("ws-status");
    wrap.innerHTML = `<span class="conn-status ${cls}"></span>${text}`;
});
// ///////////////////////////////////////////// worker
const workerScript = `
    // Worker 内部的任务队列
    let taskQueue = [];
    let isProcessing = false;

    // 辅助函数：非阻塞延时
    function sleep(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }

    // 处理队列中的下一个任务
    async function processNextTask() {
        if (taskQueue.length === 0) {
            isProcessing = false;
            return;
        }

        isProcessing = true;
        const task = taskQueue.shift(); // 取出第一个任务

        try {
            // 1. 执行延时 (非阻塞，不会卡死 Worker 的其他潜在逻辑，虽然 Worker 单线程，但这样更规范)
            if (task.delay > 0) {
                await sleep(task.delay);
            }

            // 2. 执行特定逻辑 (可以根据 type 扩展)
            let resultData = { x: task.x, y: task.y };
            
            // 这里可以添加更多复杂的计算逻辑，而不用担心阻塞 UI
            if (task.type === 0) {
                // 模拟设定值处理
                //console.log(\`Processed Set Task \${task.id}  \${task.type} \${task.x} \${task.y} \`);
            } else if (task.type === 1) {
                // 模拟计算值处理
                //console.log(\`Processed Calc Task \${task.id} \${task.type} \${task.x} \${task.y}  \`);
            }

            // 3. 将结果发回主线程
            self.postMessage({
                id: task.id,
                type: task.type,
                x: resultData.x,
                y: resultData.y,
                status: 'completed'
            });

        } catch (error) {
            self.postMessage({
                id: task.id,
                status: 'error',
                error: error.message
            });
        } finally {
            // 4. 递归处理下一个任务
            processNextTask();
        }
    }

    // 监听主线程消息
    self.onmessage = function(e) {
        const task = e.data;
        
        // 将新任务加入队列
        taskQueue.push(task);
        console.log(\` self.onmessage:Worker: Received task \${task.id}, Queue length: \${taskQueue.length}\`);

        // 如果当前没有在處理任务，则启动处理流程
        if (!isProcessing) {
            processNextTask();
        }
    };
`;



// 将脚本转换为 Data URI
const workerUri = 'data:text/javascript;charset=utf-8,' + encodeURIComponent(workerScript);
const worker = new Worker(workerUri);

worker.onmessage = function(e) {
    const res = e.data;
    //console.log(\`Main: Received result for task \${res.id}, Type: \${res.type}\`);
    
    if (res.status === 'completed') {
        if (res.type === 0) {
            setSetData({ az: res.x, el: res.y });
			//console.log("worker.onmessage setdata",res.x,res.y);
            updateBeamsVisuals();
        } else if (res.type === 1) {
            setCalcData({ az: res.x, el: res.y });
			//console.log("worker.onmessage setdata",res.x,res.y);
            updateBeamsVisuals();
        }
    }
};
// //////////////////////////////////////////// --------

// 收到ws消息回调
setMsgCallback((rawMsg)=>{
    msgCache.push(rawMsg);
    try{
        const jsonObj = JSON.parse(rawMsg);
        if(jsonObj.musicres2){
			
			const b64str = jsonObj.musicres2;
            const bytes = base64ToUint8(b64str);
            const data = unpackSensorStruct2(bytes);
			//console.log("get jsonObj.musicres2",bytes.length);
			const pmusic = data.pmusic;
			const chunkSize = 46; // 每行的数据个数
			// 1.将线性数组分割成二维数组（每46个元素一组）
			const chunks = [];
			for (let i = 0; i < pmusic.length; i += chunkSize) {
				chunks.push(pmusic.slice(i, i + chunkSize));
			}
			// 2. 将二维数组转换为字符串：
			//    -每个子数组内部用逗号连接
			//    -子数组之间用换行符 '\n' 连接
			const resultStr = chunks.map(chunk => chunk.join(',')).join('\n');
			//console.log(resultStr);

			datavalue = resultStr;
            renderScene();
		}
		if(jsonObj.musicres){
            const b64str = jsonObj.musicres;
            const bytes = base64ToUint8(b64str);
            const data = unpackSensorStruct(bytes);
            const az = Number(data.az[0]);
            const el = - Number(data.el[0]);
            
			///////
			let timeall = data.timeback - data.timesrc;
			let timecal = data.timeappe - data.timeapp;
			
			////////
            //console.log("timeSmooth：", timecal,timeall - timecal);
            const result = timeSmooth(timecal, timeall - timecal);
            const opts = getUiOptionState();
			if(opts.smoothMode){
				sliderTcalc.value = result.avg1;
			    valTcalc.textContent = result.avg1;
			    sliderTweb.value = result.avg2 ;
			    valTweb.textContent = result.avg2;
			}else{
				sliderTcalc.value = timecal;
			    valTcalc.textContent = timecal;
			    sliderTweb.value = timeall - timecal ;
			    valTweb.textContent = timeall - timecal;
			}
			//--------------
			//console.log("opts",opts);
			
            if(opts.includeWeb){
				setCalcData({az, el});
				updateBeamsVisuals();
			}else{
				/*
				const set_az = Number(data.set_az[0]);
                const set_el = - Number(data.set_el[0]);
				
				setSetData({set_az, set_el}); // must setvalue
				console.log(Date.now(),"set_az, set_el",set_az, set_el);
				updateBeamsVisuals();
				setTimeout(function() {
					setCalcData({az, el});
					console.log(Date.now(),"az, el",az, el);
					updateBeamsVisuals();
				}, timecal );   // timecal
				*/
				////////////////////////////////////////
				// 假设你已经初始化了 worker: const worker = new Worker('worker.js');

				// 全局任务计数器，用于匹配请求和响应（可选，但推荐）
				let taskIdCounter = 0;

				// --- 原有代码位置开始 ---

				const set_az = Number(data.set_az[0]);
				const set_el = -Number(data.set_el[0]);

				// 1. 构造 Type 0 任务 (设定值 Set)
				const taskSet = {
					id: ++taskIdCounter,
					type: 0,          // Type 0: 对应 setSetData
					x: set_az,        // 用 x 存储 az
					y: set_el,        // 用 y 存储 el
					delay: 0          // Type 0 通常不需要额外延时，或者你可以设一个极小值
				};

				// 2. 构造 Type 1 任务 (计算值 Calc)
				// 注意：这里的 az, el 应该是你算法计算后的最终值
				// 如果 az/el 尚未计算，请确保在这里能获取到正确的值
				const taskCalc = {
					id: ++taskIdCounter,
					type: 1,          // Type 1: 对应 setCalcData
					x: az,            // 用 x 存储 calc_az
					y: el,            // 用 y 存储 calc_el
					delay: timecal    // 这里放入你原来的 timecal 变量，作为延时毫秒数
				};

				// 3. 发送消息给 Worker
				// 我们可以一次性发送两个任务，或者分开发送。
				// 为了保持原来的“先Set，延时后Calc”的顺序，建议按顺序发送，
				// 并在 Worker 端保证队列顺序执行，或者在主线程控制发送时机。

				// 简单做法：直接发送，让 Worker 按接收顺序处理
				worker.postMessage(taskSet);
				worker.postMessage(taskCalc);

				//console.log(Date.now(), "Tasks Sent:", taskSet, taskCalc);

// --- 原有代码位置结束 ---

				////////////////////////////////////////////////
			}
		    //-------------
        }
    }catch(e){
        console.warn("解析消息失败", e);
    }
    while (msgCache.length > MAX_MSG) msgCache.shift();
});

// 发送一条角度数据到ws
async function sendAngleData(az, el) {
    let out_az = az;
    let out_el = el;
    if(az < -90) out_az = az + 90;
    if(az > 90)  out_az = az - 90;
    if(el < 0)   out_el =  - el;

    // musictx 在 musicdata.js 全局
    const rawiqdata = musictx(out_az+","+out_el);
    const strList = rawiqdata.split(',').map(s=>s.trim()).filter(s=>s.length>0);
    const floatArr = [];
    for(const s of strList){
        const v = parseFloat(s);
        if(isNaN(v)){
            console.error("解析iq失败",s);
            return;
        }
        floatArr.push(v);
    }
    if(floatArr.length!==128){
        console.log("iq数组长度不对");
        return;
    }
    const sendStruct = {
        head_len: 21*4,
        id: 1,
        timesrc: Date.now() & 0x7FFFFFFF,
        timeapp: Date.now() & 0x7FFFFFFF,
        timeappe: Date.now() & 0x7FFFFFFF,
        timeback: 0,
        time1:0,
        time2:0,
        setlen:2,
        azlen:4,
        set_az: [out_az, out_az],
        set_el: [out_el, out_el],
        az: [0,0,0,0],
        el: [0,0,0,0],
        rx_matrixlen: floatArr.length *4,
        rx_matrix: floatArr
    };
    const byteBuf = packSensorStruct(sendStruct);
    const base64Content = uint8ToBase64(byteBuf);
	
	// verify:
	//console.log("byteBuf.length",byteBuf.length,"base64Content",base64Content.length);
	//console.log("base64Content",base64Content);
	//let verfi_array = base64ToUint8(base64Content);
	//console.log( unpackSensorStruct(verfi_array)  );
	//end verify
	
    const sendData = `app,musicdata,${base64Content}`;
    //console.log("发送", sendData);
    publish(sendData);
}

// 手动更新逻辑
function handleManualUpdate() {
    const az = parseFloat(document.getElementById('slider-az').value);
    const el = parseFloat(document.getElementById('slider-el').value);
    document.getElementById('val-az').textContent = az + '°';
    document.getElementById('val-el').textContent = el + '°';
    
	////
	const opts = getUiOptionState();
    if(opts.includeWeb){
		setSetData({az, el});
        sendAngleData(az, el);
        updateBeamsVisuals();
	}else{
		sendAngleData(az, el); // only out data
	} 

}

// 扫描测试
function startSensorTest() {
    if(testInterval) clearInterval(testInterval);
    const azStart = -90;
    const azEnd = 90;
    const azStep = 1;
    const elStart = 0;
    const elEnd = 90;
    const elStep = 5;
    const intervalTime = 10;
    let currentAz = azStart;
    let currentEl = elStart;
    let isFinished = false;

    testInterval = setInterval(() => {
        if (isFinished) {
            stopSensorTest();
            return;
        }
        const setData = { az: currentAz, el: -currentEl };
        const calcData = {
            az: currentAz + (Math.random() - 0.5) * 0.5,
            el: -currentEl + (Math.random() - 0.5) * 0.5
        };
        setSetData(setData);
        setCalcData(calcData);
        sendAngleData(setData.az, setData.el);
        updateBeamsVisuals();

        document.getElementById('slider-az').value = currentAz;
        document.getElementById('slider-el').value = -currentEl;
        document.getElementById('val-az').textContent = currentAz.toFixed(1) + '°';
        document.getElementById('val-el').textContent = (-currentEl).toFixed(1) + '°';

        currentAz += azStep;
        if (currentAz > azEnd) {
            currentAz = azStart;
            currentEl += elStep;
            if (currentEl > elEnd) {
                isFinished = true;
                console.log("扫描完成");
            }
        }
    }, intervalTime);

    document.getElementById('btn-start-test').disabled = true;
    document.getElementById('btn-stop-test').disabled = false;
    document.getElementById('manual-controls').classList.add('opacity-50','pointer-events-none');
}
function stopSensorTest() {
    if(testInterval) {
        clearInterval(testInterval);
        testInterval = null;
    }
    document.getElementById('btn-start-test').disabled = false;
    document.getElementById('btn-stop-test').disabled = true;
    document.getElementById('manual-controls').classList.remove('opacity-50','pointer-events-none');
}

const azSlider = document.getElementById('slider-az');
const elSlider = document.getElementById('slider-el');
const sliderTcalc = document.getElementById('slider-tcalc');
const valTcalc = document.getElementById('val-tcalc');
const sliderTweb = document.getElementById('slider-tweb');
const valTweb = document.getElementById('val-tweb');
// UI绑定
function bindUI() {
    //const azSlider = document.getElementById('slider-az');
    //const elSlider = document.getElementById('slider-el');
    //const sliderTcalc = document.getElementById('slider-tcalc');
    //const valTcalc = document.getElementById('val-tcalc');
    //const sliderTweb = document.getElementById('slider-tweb');
    //const valTweb = document.getElementById('val-tweb');

    sliderTcalc.addEventListener('input', ()=>{
        tcalcValue = Number(sliderTcalc.value);
        valTcalc.textContent = tcalcValue;
    });
    sliderTweb.addEventListener('input', ()=>{
        twebValue = Number(sliderTweb.value);
        valTweb.textContent = twebValue;
    });
    azSlider.addEventListener('input', handleManualUpdate);
    elSlider.addEventListener('input', handleManualUpdate);
    document.getElementById('btn-manual-update').addEventListener('click', handleManualUpdate);
    document.getElementById('btn-start-test').addEventListener('click', startSensorTest);
    document.getElementById('btn-stop-test').addEventListener('click', stopSensorTest);
}
// 全局函数，核心js直接调用 getUiOptionState()
function getUiOptionState() {
	return {
		includeWeb: document.getElementById('chk-include-web').checked,
		smoothMode: document.getElementById('chk-smooth-mode').checked
	};
}
// 时间双值平滑器
function createTimeSmoother() {
    // 内部缓冲区：timhis1、timhis2，每个最多存10个
    const maxLen = 20;
    let timhis1 = [];
    let timhis2 = [];

    return function smoothTwoValue(val1, val2) {
        // 压入新数据
        timhis1.push(val1);
        timhis2.push(val2);

        // 超出长度，移除头部旧数据
        if (timhis1.length > maxLen) {
            timhis1.shift();
        }
        if (timhis2.length > maxLen) {
            timhis2.shift();
        }

        // 分别计算平均值
        const avg1 = timhis1.reduce((sum, v) => sum + v, 0) / timhis1.length;
        const avg2 = timhis2.reduce((sum, v) => sum + v, 0) / timhis2.length;

        // 返回两个均值
        return {
            avg1,
            avg2
        };
    };
}
let timeSmooth = null;
// 初始化入口
function bootstrap() {
    const container = document.getElementById('canvas-container');
    if(typeof htmlholder == "string" && htmlholder == "mesh"){
		
		initScene_mesh(container);
	}else{
		if(typeof initScene == "function")
	    initScene(container);
	}
	
    bindUI();
	timeSmooth = createTimeSmoother();
}
bootstrap();
