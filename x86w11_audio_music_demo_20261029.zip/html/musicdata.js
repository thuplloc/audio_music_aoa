
/**
 * 均匀圆阵 (UCA) 接收信号生成器
 * 根据给定的方位角(Az)和俯仰角(El)，生成 M 个阵元的复数接收信号。
 * 输出格式：长度为 2*M 的 Float64Array，每两个元素代表一个复数 [Re, Im]。
 */
let g_noise_flag = 0;
class Complex {
    constructor(re, im) {
        this.re = re;
        this.im = im;
    }

    add(other) {
        return new Complex(this.re + other.re, this.im + other.im);
    }

    mul(other) {
        if (typeof other === 'number') {
            return new Complex(this.re * other, this.im * other);
        }
        // Complex multiplication: (a+bi)(c+di) = (ac-bd) + (ad+bc)i
        return new Complex(
            this.re * other.re - this.im * other.im,
            this.re * other.im + this.im * other.re
        );
    }

    static exp(jTheta) {
        // e^(j*theta) = cos(theta) + j*sin(theta)
        return new Complex(Math.cos(jTheta), Math.sin(jTheta));
    }
}

/**
 * 生成高斯分布随机数 (Box-Muller transform)
 */
function randn() {
    let u = 0, v = 0;
    while (u === 0) u = Math.random();
    while (v === 0) v = Math.random();
    return Math.sqrt(-2.0 * Math.log(u)) * Math.cos(2.0 * Math.PI * v);
}

/**
 * 生成复数高斯噪声
 */
function complexRandn() {
    return new Complex(randn() / Math.sqrt(2), randn() / Math.sqrt(2));
}

/**
 * 主函数：生成单行数据对应的接收信号
 * @param {number} azDeg - 方位角 (度)
 * @param {number} elDeg - 俯仰角 (度)
 * @param {Object} params - 阵列参数
 * @returns {Float64Array} - 长度为 2*M 的数组，[Re0, Im0, Re1, Im1, ...]
 */
function generateUCASignal(azDeg, elDeg, params = {}) {
    // 默认参数，可根据需要调整
    const M = params.M || 8;
    const lambda = params.lambda || 0.125;
    const r = params.r || (0.5 * lambda);
    const N_snapshots = params.N_snapshots || 1024; // 快拍数，用于统计功率，但输出通常指瞬时或平均导向矢量？
    // 注意：题目要求“输出是8个sensor对应的8个复数”。
    // 在DOA估计中，通常 X 是 M x N 矩阵。
    // 如果只输出“8个复数”，这通常指的是**无噪声的导向矢量 A(:,1)** 或者 **单次快拍的接收信号 X(:,t)**。
    // 考虑到题目提到 SNR 和 Noise，且说“生成接收信号”，最合理的解释是生成**某一次快拍(t)** 的接收数据向量，
    // 或者生成**导向矢量**作为基础。
    // 但题目明确说了 "SNR=20... 生成匹配SNR的高斯白噪声... X = A*S + N"。
    // 如果只输出8个复数，我们无法输出整个 X (M x N)。
    // 通常这种接口用于测试算法输入，可能是指**导向矢量**（确定性部分）或者**单次采样**。
    // 鉴于“每次调用只根据一行生成”，且输入是角度，输出是8个复数。
    // 如果包含噪声，每次调用结果不同。如果不含噪声，则是导向矢量。
    // 题目中 Matlab 代码生成了完整的 X 矩阵。
    // 这里我将实现生成**单次快拍 (Single Snapshot)** 的接收信号向量，因为这是包含噪声影响的最小完整单元。
    // 如果需要导向矢量，可以将噪声部分移除。

    const SNR = params.SNR !== undefined ? params.SNR : 20;
    
    // 1. 构建导向矢量 A (M x 1) 对于当前角度
    const azRad = azDeg * Math.PI / 180;
    const elRad = elDeg * Math.PI / 180;
    
    // 波矢量 k
    const k = (2 * Math.PI) / lambda;
    const kx = k * Math.cos(elRad) * Math.cos(azRad);
    const ky = k * Math.cos(elRad) * Math.sin(azRad);
    const kz = k * Math.sin(elRad);
    
    // 阵元位置与相位计算
    const A_vec = []; // Array of Complex
    for (let m = 0; m < M; m++) {
        const angle_m = m * (2 * Math.PI / M);
        const px = r * Math.cos(angle_m);
        const py = r * Math.sin(angle_m);
        const pz = 0;
        
        // phase = -k' * pos = -(kx*px + ky*py + kz*pz)
        const phase = -(kx * px + ky * py + kz * pz);
        A_vec.push(Complex.exp(phase));
    }
    
	const X_vec = [];
	for(let nap=0;nap < N_snapshots;nap++){
		// 2. 生成信号源 S (1 x 1) 对于单次快拍
		// S 是标量，因为 K=1 (每行对应一个源)
		//const S = complexRandn(); 
		const S = new Complex(-0.0617, - 0.4818);
		
		// console.log("S is fixed not randon. -0.0617 - 0.4818i ");
		// 3. 计算信号功率并调整幅度以匹配 SNR
		// E[|S|^2] = 1 (因为 randn/sqrt(2) 的方差为 1/2+1/2=1)
		// 信号功率 Ps = |S|^2 ? 不，SNR 定义通常基于期望功率。
		// Ps_expected = 1.
		// Pn_expected = Ps_expected / 10^(SNR/10)
		const snrLinear = Math.pow(10, SNR / 10);
		const noisePower = 1 / snrLinear;
		const noiseStd = Math.sqrt(noisePower / 2); // 实部和虚部各占一半功率
		
		// 4. 生成噪声 N (M x 1)
		
		for (let m = 0; m < M; m++) {
			// X = A * S + N
			const signalComponent = A_vec[m].mul(S);
			const noiseComponent = new Complex(randn() * noiseStd, randn() * noiseStd);
			
			if(g_noise_flag > 0){
				X_vec.push(signalComponent.add(noiseComponent));
			}else{
				X_vec.push(signalComponent);
			}
		}
		
	}
    
    // 5. 转换为 Float64Array [Re0, Im0, Re1, Im1, ...]
    const output = new Float64Array(2 * M * N_snapshots);
    for (let i = 0; i < M*N_snapshots; i++) {
        output[2 * i] = X_vec[i].re;
        output[2 * i + 1] = X_vec[i].im;
    }
    
    return output;
}

// 示例用法与测试
function musictx(inputData) {
     inputData = inputData.trim();
     //inputData = "10,20";
    const lines = inputData.split('\n');
    
    console.log("开始生成 UCA 接收信号...",lines);
    let onesigdata ;
    lines.forEach((line, index) => {
        const parts = line.split(',').map(Number);
        if (parts.length === 2 && !isNaN(parts[0]) && !isNaN(parts[1])) {
            const az = parts[0];
            const el = parts[1];
            
            // 生成信号
            const signalData = generateUCASignal(az, el,{"N_snapshots" : 8});
           
            // 格式化输出
            const complexStrs = [];
            for (let i = 0; i < signalData.length; i += 2) {
                const re = signalData[i].toFixed(6);
                const im = signalData[i+1].toFixed(6);
                const sign = im >= 0 ? '+' : '-';
                complexStrs.push(`(${re}${sign}${Math.abs(im)}j)`);
            }
            
            //console.log(`Line ${index + 1} [Az:${az}, El:${el}]:`);
            //console.log(`  Output Array: [${complexStrs.join(', ')}]`);
            //console.log(`  Raw Float64: [${Array.from(signalData).map(n => n.toFixed(4)).join(', ')}]`);
			rawfloat = `${Array.from(signalData).map(n => n.toFixed(4)).join(', ')}` ;
            //console.log("rawfloat",rawfloat);
			onesigdata=rawfloat;
			
        }
    });
	return onesigdata;
}

// 如果在 Node.js 环境中运行
if (typeof require !== 'undefined' && require.main === module) {
    main();
}

// 导出函数以便在其他模块使用
if (typeof module !== 'undefined' && module.exports) {
    module.exports = { generateUCASignal };
}
